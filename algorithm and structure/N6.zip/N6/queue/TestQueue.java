public class TestQueue {
    public static void main(String[] args) {

        MyQueue<Integer> queue = new MyQueue<>();

        System.out.println("stack is empty? " + queue.isEmpty());
        queue.enQueue(1);
        queue.enQueue(2);
        queue.print();

        // System.out.println(stacgetLastk.print());
        // System.out.println(stack.getLast());

        System.out.println("front of queue is " + queue.front());
        queue.enQueue(3);
        // queue.print();
        System.out.println("front of queue is " + queue.deQueue());
        queue.enQueue(4);
        // queue.print();
        queue.deQueue();
        queue.deQueue();
        System.out.println("front of queue is " + queue.front());

        queue.print();
    }
}
