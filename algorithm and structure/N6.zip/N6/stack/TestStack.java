public class TestStack {
    public static void main(String[] args) {

        MyStack<Integer> stack = new MyStack<>();

        System.out.println("stack is empty? " + stack.isEmpty());
        stack.push(1);
        stack.push(2);

        // System.out.println(stacgetLastk.print());
        // stack.print();
        // System.out.println(stack.getLast());

        System.out.println("top of stack is " + stack.peek());
        stack.push(3);
        System.out.println("top of stack is " + stack.pop());
        stack.push(4);
        stack.pop();
        stack.pop();
        System.out.println("top of stack is " + stack.peek());
    }
}
